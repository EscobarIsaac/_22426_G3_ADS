package servicio;

import modelo.Estudiante;
import repositorio.EstudianteRepositorio;

import java.util.List;

public class EstudianteServicio {
    private final EstudianteRepositorio repo = new EstudianteRepositorio();

    public void agregarEstudiante(Estudiante e) {
        repo.agregar(e);
    }

    public List<Estudiante> obtenerEstudiantes() {
        return repo.listar();
    }

    public Estudiante obtenerPorOrden(int orden) {
        return repo.buscarPorOrden(orden);
    }

    public boolean modificarEstudiante(Estudiante e) {
        return repo.actualizar(e);
    }

    public boolean eliminarEstudiante(int orden) {
        return repo.eliminar(orden);
    }
}
