package repositorio;

import modelo.Estudiante;
import java.util.ArrayList;
import java.util.List;

public class EstudianteRepositorio {
    private final List<Estudiante> estudiantes = new ArrayList<>();

    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }

    public List<Estudiante> listar() {
        return estudiantes;
    }

    public Estudiante buscarPorOrden(int orden) {
        return estudiantes.stream().filter(e -> e.getOrden() == orden).findFirst().orElse(null);
    }

    public boolean actualizar(Estudiante actualizado) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getOrden() == actualizado.getOrden()) {
                estudiantes.set(i, actualizado);
                return true;
            }
        }
        return false;
    }

    public boolean eliminar(int orden) {
        return estudiantes.removeIf(e -> e.getOrden() == orden);
    }
}
