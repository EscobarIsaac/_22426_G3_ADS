package modelo;

import java.util.ArrayList;
import java.util.List;

public class GrupoEstudiante implements ComponenteEstudiante {
    private String nombreGrupo;
    private List<ComponenteEstudiante> componentes = new ArrayList<>();

    public GrupoEstudiante(String nombreGrupo) {
        this.nombreGrupo = nombreGrupo;
    }

    public void agregar(ComponenteEstudiante componente) {
        componentes.add(componente);
    }

    @Override
    public void mostrar() {
        System.out.println("Grupo: " + nombreGrupo);
        for (ComponenteEstudiante c : componentes) {
            c.mostrar();
        }
    }
}
