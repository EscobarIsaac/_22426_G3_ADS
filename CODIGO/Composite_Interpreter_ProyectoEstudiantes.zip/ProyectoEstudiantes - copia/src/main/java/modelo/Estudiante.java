package modelo;

public class Estudiante {
    private int orden;
    private String nombre;
    private int edad;

    public Estudiante(int orden, String nombre, int edad) {
        this.orden = orden;
        this.nombre = nombre;
        this.edad = edad;
    }

    public int getOrden() { return orden; }
    public void setOrden(int orden) { this.orden = orden; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getEdad() { return edad; }
    public void setEdad(int edad) { this.edad = edad; }

    @Override
    public String toString() {
        return "Estudiante{" + "orden=" + orden + ", nombre='" + nombre + '\'' + ", edad=" + edad + '}';
    }
}
