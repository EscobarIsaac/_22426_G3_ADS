package modelo;

public class EstudianteHoja implements ComponenteEstudiante {
    private Estudiante estudiante;

    public EstudianteHoja(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    @Override
    public void mostrar() {
        System.out.println("Estudiante: " + estudiante);
    }
}
