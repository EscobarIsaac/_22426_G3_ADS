package modelo;

public interface ComponenteEstudiante {
    void mostrar();
}
