package presentacion;

import modelo.Estudiante;
import servicio.EstudianteServicio;

public class ComandoAgregar implements Comando {
    @Override
    public void interpretar(String[] tokens, EstudianteServicio servicio) {
        int id = Integer.parseInt(tokens[1]);
        String nombre = tokens[2];
        int edad = Integer.parseInt(tokens[3]);
        servicio.agregarEstudiante(new Estudiante(id, nombre, edad));
    }
}
