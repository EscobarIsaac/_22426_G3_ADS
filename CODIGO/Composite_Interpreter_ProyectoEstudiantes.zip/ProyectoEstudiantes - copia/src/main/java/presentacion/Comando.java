package presentacion;

import servicio.EstudianteServicio;

public interface Comando {
    void interpretar(String[] tokens, EstudianteServicio servicio);
}
