package presentacion;

import modelo.Estudiante;
import servicio.EstudianteServicio;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class EstudianteUI extends JFrame {
    private JTextField txtId, txtNombre, txtEdad;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private EstudianteServicio servicio;

    public EstudianteUI() {
        servicio = new EstudianteServicio();

        setTitle("CRUD Estudiantes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setSize(600, 420);
        setLocationRelativeTo(null);

        JLabel lblId = new JLabel("ID:");
        lblId.setBounds(20, 20, 50, 25);
        add(lblId);

        txtId = new JTextField();
        txtId.setBounds(60, 20, 100, 25);
        add(txtId);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(180, 20, 70, 25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(240, 20, 150, 25);
        add(txtNombre);

        JLabel lblEdad = new JLabel("Edad:");
        lblEdad.setBounds(410, 20, 50, 25);
        add(lblEdad);

        txtEdad = new JTextField();
        txtEdad.setBounds(460, 20, 50, 25);
        add(txtEdad);

        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(20, 60, 100, 25);
        add(btnAgregar);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(130, 60, 100, 25);
        add(btnActualizar);

        //Eliminar
        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(240, 60, 100, 25);
        add(btnEliminar);


        JButton btnMostrar = new JButton("Mostrar Todo");
        btnMostrar.setBounds(350, 60, 160, 25);
        add(btnMostrar);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(240, 330, 100, 25);
        add(btnBuscar);

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Nombre", "Edad"}, 0);
        tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);
        scrollPane.setBounds(20, 100, 540, 220);
        add(scrollPane);

        btnAgregar.addActionListener(e -> {
            String idText = txtId.getText().trim();
            String nombre = txtNombre.getText().trim();
            String edadText = txtEdad.getText().trim();

            if (idText.isEmpty() || nombre.isEmpty() || edadText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor complete todos los campos.");
                return;
            }

            try {
                int id = Integer.parseInt(idText);
                int edad = Integer.parseInt(edadText);
                servicio.agregarEstudiante(new Estudiante(id, nombre, edad));
                limpiarCampos();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID y Edad deben ser números válidos.");
            }
        });

        btnActualizar.addActionListener(e -> {
            String idText = txtId.getText().trim();
            String nombre = txtNombre.getText().trim();
            String edadText = txtEdad.getText().trim();

            if (idText.isEmpty() || nombre.isEmpty() || edadText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor complete todos los campos.");
                return;
            }

            try {
                int id = Integer.parseInt(idText);
                int edad = Integer.parseInt(edadText);
                boolean ok = servicio.modificarEstudiante(new Estudiante(id, nombre, edad));
                JOptionPane.showMessageDialog(this, ok ? "Actualizado" : "No encontrado");
                limpiarCampos();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID y Edad deben ser números válidos.");
            }
        });

        // Boton Eliminar
        btnEliminar.addActionListener(e -> {
            String idText = txtId.getText().trim();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese el ID a eliminar.");
                return;
            }

            try {
                int id = Integer.parseInt(idText);
                boolean ok = servicio.eliminarEstudiante(id);
                JOptionPane.showMessageDialog(this, ok ? "Eliminado" : "No encontrado");
                limpiarCampos();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID debe ser un número válido.");
            }
        });

        btnMostrar.addActionListener(e -> {
            modeloTabla.setRowCount(0);
            for (Estudiante est : servicio.obtenerEstudiantes()) {
                modeloTabla.addRow(new Object[]{est.getOrden(), est.getNombre(), est.getEdad()});
            }
        });

        btnBuscar.addActionListener(e -> {
            String idText = txtId.getText().trim();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese el ID a buscar.");
                return;
            }

            try {
                int id = Integer.parseInt(idText);
                Estudiante buscado = servicio.obtenerPorOrden(id);
                modeloTabla.setRowCount(0);
                if (buscado != null) {
                    modeloTabla.addRow(new Object[]{buscado.getOrden(), buscado.getNombre(), buscado.getEdad()});
                } else {
                    JOptionPane.showMessageDialog(this, "Estudiante no encontrado");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID debe ser un número válido.");
            }
        });

        setVisible(true);
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtNombre.setText("");
        txtEdad.setText("");
    }
}
