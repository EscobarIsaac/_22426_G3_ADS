package presentacion;

import servicio.EstudianteServicio;

public class ComandoEliminar implements Comando {
    @Override
    public void interpretar(String[] tokens, EstudianteServicio servicio) {
        int id = Integer.parseInt(tokens[1]);
        servicio.eliminarEstudiante(id);
    }
}
