
import java.net.*;
import java.io.*;

public class Main {
    public static void main(String[] args) {
        int puerto = 5000;
        try (ServerSocket servidor = new ServerSocket(puerto)) {
            System.out.println("Servidor escuchando en el puerto " + puerto);
            Socket cliente = servidor.accept();
            System.out.println("Cliente conectado: " + cliente.getInetAddress());

            BufferedReader entrada = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
            PrintWriter salida = new PrintWriter(cliente.getOutputStream(), true);

            String cuenta = entrada.readLine();
            System.out.println("Petición recibida para la cuenta: " + cuenta);

            String respuestaSaldo = "El saldo de la cuenta " + cuenta + " es $1,234.56";
            salida.println(respuestaSaldo);
            System.out.println("Respuesta enviada al cliente.");

            cliente.close();
            System.out.println("Conexión cerrada.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
