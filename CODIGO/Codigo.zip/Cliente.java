
import java.net.*;
import java.io.*;

public class Cliente {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 5000;
        try (Socket socket = new Socket(host, puerto)) {
            System.out.println("Conectado al servidor");

            BufferedReader entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter salida = new PrintWriter(socket.getOutputStream(), true);

            String cuenta = "123456789";
            System.out.println("Solicitando saldo de la cuenta: " + cuenta);
            salida.println(cuenta);

            String respuesta = entrada.readLine();
            System.out.println("Respuesta del servidor: " + respuesta);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
