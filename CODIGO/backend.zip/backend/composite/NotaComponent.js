class NotaComponent {
  getValor() {
    throw new Error("Método abstracto no implementado");
  }
}

module.exports = NotaComponent;
