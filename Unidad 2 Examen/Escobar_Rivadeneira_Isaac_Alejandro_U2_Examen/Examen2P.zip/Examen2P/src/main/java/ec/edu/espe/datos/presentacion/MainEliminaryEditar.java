package ec.edu.espe.datos.presentacion;

import ec.edu.espe.datos.logica_negocio.EstudianteService;
import ec.edu.espe.datos.model.Estudiante;

import java.util.Scanner;

public class MainEliminaryEditar {
    public static void main(String[] args) {
        EstudianteService service = new EstudianteService();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n MENÚ - ESTUDIANTES ");
            System.out.println("1. Crear estudiante");
            System.out.println("2. Listar estudiantes");
            System.out.println("3. Editar estudiante");
            System.out.println("4. Eliminar estudiante");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese ID: ");
                    int id = scanner.nextInt(); scanner.nextLine();
                    System.out.print("Ingrese apellidos: ");
                    String apellidos = scanner.nextLine();
                    System.out.print("Ingrese nombres: ");
                    String nombres = scanner.nextLine();
                    System.out.print("Ingrese edad: ");
                    int edad = scanner.nextInt();
                    service.crearEstudiante(id, apellidos, nombres, edad);
                    System.out.println(" Estudiante creado.");
                    break;

                case 2:
                    System.out.println(" Lista de estudiantes:");
                    EstudianteUI.mostrarEstudiantes(service.obtenerTodos());
                    break;

                case 3:
                    System.out.print("Ingrese ID del estudiante a editar: ");
                    int idEditar = scanner.nextInt(); scanner.nextLine();
                    System.out.print("Nuevos apellidos: ");
                    String nuevosApellidos = scanner.nextLine();
                    System.out.print("Nuevos nombres: ");
                    String nuevosNombres = scanner.nextLine();
                    System.out.print("Nueva edad: ");
                    int nuevaEdad = scanner.nextInt();
                    boolean editado = service.editarEstudiante(idEditar, nuevosApellidos, nuevosNombres, nuevaEdad);
                    System.out.println(editado ? " Estudiante editado correctamente." : " Estudiante no encontrado.");
                    break;

                case 4:
                    System.out.print("Ingrese ID del estudiante a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    boolean eliminado = service.eliminarEstudiante(idEliminar);
                    System.out.println(eliminado ? "Estudiante eliminado." : " Estudiante no encontrado.");
                    break;

                case 0:
                    System.out.println(" Haz salido del sistema");
                    break;

                default:
                    System.out.println(" Intenta de nuevo");
            }

        } while (opcion != 0);

        scanner.close();
    }
}

