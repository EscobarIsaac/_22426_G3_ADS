package ec.edu.espe.datos.controller;

import ec.edu.espe.datos.dao.EstudianteDAO;
import ec.edu.espe.datos.model.Estudiante;
import java.util.List;

public class EstudianteController {
    private EstudianteDAO dao = new EstudianteDAO();

    public void crearEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);
        dao.agregar(e);
    }

    public List<Estudiante> obtenerTodos() {
        return dao.listar();
    }

    public Estudiante buscarEstudiante(int id) {
        return dao.buscarPorId(id);
    }
}
