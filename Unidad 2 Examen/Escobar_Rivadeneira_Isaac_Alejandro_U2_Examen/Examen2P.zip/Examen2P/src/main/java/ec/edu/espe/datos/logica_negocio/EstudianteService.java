package ec.edu.espe.datos.logica_negocio;

import ec.edu.espe.datos.model.Estudiante;
import ec.edu.espe.datos.repository.EstudianteRepository;
import java.util.List;

public class EstudianteService {
    private EstudianteRepository repository = new EstudianteRepository();

    public void crearEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);
        repository.agregar(e);
    }

    public List<Estudiante> obtenerTodos() {
        return repository.listar();
    }

    public Estudiante buscarEstudiante(int id) {
        return repository.buscarPorId(id);
    }

    public boolean editarEstudiante(int id, String nuevosApellidos, String nuevosNombres, int nuevaEdad) {
        Estudiante editado = new Estudiante(id, nuevosApellidos, nuevosNombres, nuevaEdad);
        return repository.editar(editado);
    }

    public boolean eliminarEstudiante(int id) {
        return repository.eliminar(id);
    }
}
