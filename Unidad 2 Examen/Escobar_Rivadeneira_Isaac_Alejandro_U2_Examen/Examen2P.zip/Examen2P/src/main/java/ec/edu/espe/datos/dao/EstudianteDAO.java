package ec.edu.espe.datos.dao;

import java.util.ArrayList;
import java.util.List;
import ec.edu.espe.datos.model.Estudiante;

public class EstudianteDAO {
    private List<Estudiante> estudiantes = new ArrayList<>();

    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }

    public List<Estudiante> listar() {
        return estudiantes;
    }

    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) {
                return e;
            }
        }
        return null;
    }
}
