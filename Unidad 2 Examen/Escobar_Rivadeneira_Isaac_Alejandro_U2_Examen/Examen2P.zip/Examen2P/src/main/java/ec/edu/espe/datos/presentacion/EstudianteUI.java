package ec.edu.espe.datos.presentacion;

import ec.edu.espe.datos.model.Estudiante;
import java.util.List;

public class EstudianteUI {
    public static void mostrarEstudiantes(List<Estudiante> estudiantes) {
        for (Estudiante e : estudiantes) {
            System.out.println(e.getId() + " - " + e.getApellidos() + " " + e.getNombres() + " - Edad: " + e.getEdad());
        }
    }
}